
interface Allatok {
  id: number;
  Nev: string;
  kor: number;
  fajta: string;
  leiras: string;
}

import { useEffect, useState } from 'react'
import './App.css'

function App() {
  
  const [ allatok, setAllatok ] = useState([] as Allatok[])
  
  useEffect(() => {
    async function load() {
      const response = await fetch('http://localhost:3000/allatkert')
      const allatok = await response.json() as Allatok[];
      setAllatok(allatok);
      console.log(allatok);
    }
    load()
  }, [])

  return <div>
    <ul>
      {
        allatok.map(allat => <li key={allat.id}>{allat.Nev}</li>)
      }
    </ul>
  </div>
}

export default App
