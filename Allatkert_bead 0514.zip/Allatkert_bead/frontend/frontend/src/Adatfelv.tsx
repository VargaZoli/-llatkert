export function Adatfelv(){
    return <form  > Név  <input type="text"/> <br></br>
    
    Kor<input type="number" /> <br />
    Fajta <input type="text" /> <br />
    Leírás <input type="text" />

<br />
<button type={"submit"}>Felvétel</button>
     </form>
}

