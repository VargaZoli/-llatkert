document.addEventListener('DOMContentLoaded',async()=>{
  let eredmeny=await fetch('http://localhost:3000/autok');
  let data=await eredmeny.json();
  console.log(data);


 


})
