import express from "express";
import mysql from 'mysql2';
import cors from 'cors';


const app = express();
app.use(cors());


const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: '12e',
}).promise();

app.get('/', (req,res)=>{
    res.send("Autó lista");
});

app.get('/autok', async (req,res)=>{
    //res.send("autók listája");
    const temp = await db.query('SELECT Id, Márka, Tipus, Suly FROM autok')
    const rows = temp[0];
    const fields = temp[1];
    res.send(rows);
});

app.get('/autok/:autoId', async (req,res)=>{
    let autoId = parseInt(req.params.autoId);
    const [rows, fields] = await db.query('SELECT id, Márka, Tipus, Suly FROM autok WHERE id = ?', [autoId]);
    if (rows.length == 1){
        res.send(rows[0]);
    } else {
        res.status(404).send({error: 'Nincs ilyen autó!'});
    }
});






const list = document.getElementById("list");

list.innerHTML += `<li><a href="#">Item ${list.children.length + 1}</a></li>`;  

app.listen(3000);