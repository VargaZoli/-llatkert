
import { useEffect, useState } from 'react';
import './App.css';
import { Adatfelv } from './Adatfelv';

interface Allatok {
  id: number;
  Nev: string;
  Eletkor: number;
  Fajta: string;
  Leírás: string;
}

function App() {
  const [allatok, setAllatok] = useState<Allatok[]>([]);
  const [selectedAnimal, setSelectedAnimal] = useState<Allatok | null>(null);

  useEffect(() => {
    async function load() {
      const response = await fetch('http://localhost:3000/allatkert');
      const allatok = (await response.json()) as Allatok[];
      setAllatok(allatok);
    }
    load();
  }, []);

  const handleAnimalClick = (animal: Allatok) => {
    setSelectedAnimal((prevSelected) => (prevSelected?.id === animal.id ? null : animal));
  };

  return (
    <div className="container">
      <h1>Állatkert</h1>
      <ul>
        {allatok.map((allat) => (
          <li key={allat.id} onClick={() => handleAnimalClick(allat)}>
            <span>{allat.Nev}</span> 
            {selectedAnimal?.id === allat.id && (
              <div className="dropdown">
                <p><strong>Fajta:</strong> {allat.Fajta}</p>
                <p><strong>ID:</strong> {allat.id}</p>
                <p><strong>Leírás:</strong> {allat.Leírás}</p>
              </div>
            )}
          </li>
        ))}
      </ul>
      <Adatfelv />
    </div>
  );
}

export default App;
