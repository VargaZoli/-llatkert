// Adatfelv.tsx
import React, { useState, ChangeEvent, FormEvent } from 'react';
import axios from 'axios';

export const Adatfelv: React.FC = () => {
  const [formData, setFormData] = useState({
    Nev: '',
    Eletkor: 0,
    Fajta: '',
    Leírás: ''
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3000/allatkert', formData);
      console.log('Data submitted successfully:', response.data);
    } catch (error) {
      console.error('Error submitting data:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Név:
        <input type="text" name="Nev" value={formData.Nev} onChange={handleChange} />
      </label>
      <br />
      <label>
        Eletkor:
        <input type="number" name="Eletkor" value={formData.Eletkor} onChange={handleChange} />
      </label>
      <br />
      <label>
        Fajta:
        <input type="text" name="Fajta" value={formData.Fajta} onChange={handleChange} />
      </label>
      <br />
      <label>
        Leírás:
        <input type="text" name="Leírás" value={formData.Leírás} onChange={handleChange} />
      </label>
      <br />
      <button type="submit">Felvétel</button>
    </form>
  );
};


