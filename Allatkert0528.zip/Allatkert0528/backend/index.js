// server.js
import express from 'express';
import mysql from 'mysql2/promise';
import cors from 'cors';

const app = express();
app.use(express.json());
app.use(cors());

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'allatkert',
});

app.get('/allatkert', async (req, res) => {
    const [rows] = await db.query('SELECT id, Nev, Eletkor, Fajta, Leírás FROM allatkert');
    res.status(200).send(rows);
});

app.post('/allatkert', async (req, res) => {
    const { Nev, Eletkor, Fajta, Leírás } = req.body;
    try {
        const [result] = await db.query('INSERT INTO allatkert (Nev, Eletkor, Fajta, Leírás) VALUES (?, ?, ?, ?)', [Nev, Eletkor, Fajta, Leírás]);
        res.status(201).send({
            id: result.insertId,
            Nev,
            Eletkor,
            Fajta,
            Leírás
        });
    } catch (error) {
        console.error('HIBA', error);
        res.status(500).send({ error: 'HIBA' });
    }
});

app.listen(3000, () => {
  
});
